#ifndef DECRYPT_H
#define DECRYPT_H

using namespace std;

int decrypt(int cryptSize, string encrypted_file);

#endif // DECRYPT_H
