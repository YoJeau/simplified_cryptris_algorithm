// Emplacements des diff�rents fichiers n�cessaires et/ou g�n�r�s � l'utilisation
#define dir_path "files/"
#define sk_path "files/sk.txt"
#define pk_path "files/pk.txt"
#define ec_path "files/encrypted_message.txt"
#define dc_path "files/decrypted_message.txt"
#define asciiToTrits_path "files/asciiToTrits.txt"
#define tritsToAscii_path "files/tritsToAscii.txt"
