#ifndef SK_GEN_H
#define SK_GEN_H

using namespace std;

int sk_gen(int cryptSize);

#endif // SK_GEN_H
