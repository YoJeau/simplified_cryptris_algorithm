#ifndef ENCRYPT_H
#define ENCRYPT_H

using namespace std;

int encrypt(int cryptSize, string message_file);

#endif // ENCRYPT_H
